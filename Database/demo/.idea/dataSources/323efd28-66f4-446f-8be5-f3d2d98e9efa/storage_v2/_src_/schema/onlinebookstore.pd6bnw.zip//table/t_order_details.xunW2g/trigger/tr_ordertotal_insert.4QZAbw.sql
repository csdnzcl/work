create definer = root@localhost trigger TR_OrderTotal_Insert
    after insert
    on t_order_details
    for each row
BEGIN
    UPDATE T_ORDERS SET Total_Amount = Total_Amount + (NEW.Quantity * NEW.Unit_Price)
    WHERE OrderID = NEW.OrderID;
END;

