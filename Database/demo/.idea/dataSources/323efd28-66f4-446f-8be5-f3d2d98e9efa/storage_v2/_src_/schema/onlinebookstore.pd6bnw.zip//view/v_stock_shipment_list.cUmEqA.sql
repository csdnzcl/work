create definer = root@localhost view v_stock_shipment_list as
select `o`.`OrderID`    AS `OrderID`,
       `o`.`Order_Date` AS `Order_Date`,
       `c`.`Name`       AS `Customer_Name`,
       `o`.`Address`    AS `Shipping_Address`,
       `b`.`Title`      AS `Book_Title`,
       `od`.`Quantity`  AS `Quantity`
from (((`onlinebookstore`.`t_orders` `o` join `onlinebookstore`.`t_order_details` `od`
        on ((`o`.`OrderID` = `od`.`OrderID`))) join `onlinebookstore`.`t_books` `b`
       on ((`od`.`ISBN` = `b`.`ISBN`))) join `onlinebookstore`.`t_customers` `c`
      on ((`o`.`CustomerID` = `c`.`CustomerID`)))
where (`o`.`Status` = 'Paid');

