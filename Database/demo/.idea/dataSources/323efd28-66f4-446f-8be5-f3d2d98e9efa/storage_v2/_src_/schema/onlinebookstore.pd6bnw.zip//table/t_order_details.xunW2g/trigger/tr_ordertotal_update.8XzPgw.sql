create definer = root@localhost trigger TR_OrderTotal_Update
    after update
    on t_order_details
    for each row
BEGIN
    IF (NEW.Quantity != OLD.Quantity) OR (NEW.Unit_Price != OLD.Unit_Price) THEN
        UPDATE T_ORDERS
        SET Total_Amount = Total_Amount - (OLD.Quantity * OLD.Unit_Price) + (NEW.Quantity * NEW.Unit_Price)
        WHERE OrderID = NEW.OrderID;
    END IF;
END;

