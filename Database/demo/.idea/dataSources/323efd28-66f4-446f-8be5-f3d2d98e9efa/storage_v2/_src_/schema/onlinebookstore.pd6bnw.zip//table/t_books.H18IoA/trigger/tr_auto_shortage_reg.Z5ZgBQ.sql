create definer = root@localhost trigger TR_Auto_Shortage_Reg
    after update
    on t_books
    for each row
BEGIN
    DECLARE v_SuggestQty INT;
    -- 1. 仅当库存发生变化且低于警戒线时触发
    IF NEW.Stock_Qty != OLD.Stock_Qty AND NEW.Stock_Qty < NEW.Min_Stock THEN
        -- 计算建议补货量：(警戒线 - 当前库存) + 10本缓冲
        SET v_SuggestQty = (NEW.Min_Stock - NEW.Stock_Qty) + 10;

        -- 2. 检查是否已存在未处理的缺货记录
        IF EXISTS (SELECT 1 FROM T_SHORTAGE WHERE ISBN = NEW.ISBN AND Status = 'Unprocessed') THEN
            UPDATE T_SHORTAGE
            SET
                -- 如果系统建议的补货量更大，则更新数量；若用户手动要求的数量更多，则保留用户值
                Quantity = CASE
                               WHEN Quantity < v_SuggestQty THEN v_SuggestQty
                               ELSE Quantity
                    END,
                -- 如果原记录是 User，则改为 Auto/User，体现双重需求
                Source = CASE
                             WHEN Source = 'User' THEN 'Auto/User'
                             ELSE Source
                    END,
                Shortage_Date = NOW()
            WHERE ISBN = NEW.ISBN AND Status = 'Unprocessed';
        ELSE
            -- 3. 若无记录，则新建系统自动预警记录
            INSERT INTO T_SHORTAGE (ISBN, Shortage_Date, Quantity, Source, Status)
            VALUES (NEW.ISBN, NOW(), v_SuggestQty, 'Auto', 'Unprocessed');
        END IF;
    END IF;
END;

