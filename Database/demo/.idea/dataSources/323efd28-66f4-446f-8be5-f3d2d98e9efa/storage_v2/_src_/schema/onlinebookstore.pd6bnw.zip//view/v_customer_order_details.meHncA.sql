create definer = root@localhost view v_customer_order_details as
select `o`.`CustomerID`                      AS `CustomerID`,
       `o`.`OrderID`                         AS `OrderID`,
       `o`.`Order_Date`                      AS `Order_Date`,
       `o`.`Status`                          AS `Status`,
       `b`.`Title`                           AS `Title`,
       `od`.`Quantity`                       AS `Quantity`,
       `od`.`Unit_Price`                     AS `Original_Price`,
       (`od`.`Quantity` * `od`.`Unit_Price`) AS `SubTotal_Before_Discount`
from ((`onlinebookstore`.`t_orders` `o` join `onlinebookstore`.`t_order_details` `od`
       on ((`o`.`OrderID` = `od`.`OrderID`))) join `onlinebookstore`.`t_books` `b` on ((`od`.`ISBN` = `b`.`ISBN`)));

-- comment on column v_customer_order_details.Status not supported: 状态: Pending, Paid, Payment Failed

-- comment on column v_customer_order_details.Original_Price not supported: 成交时的原价单价

