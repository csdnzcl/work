create definer = root@localhost trigger TR_Restock_Clear_Shortage
    after update
    on t_books
    for each row
BEGIN
    IF NEW.Stock_Qty > OLD.Stock_Qty AND NEW.Stock_Qty >= NEW.Min_Stock THEN
        UPDATE T_SHORTAGE SET Status = 'Done' WHERE ISBN = NEW.ISBN AND Status = 'Unprocessed';
    END IF;
END;

