create
    definer = root@localhost procedure SP_User_Report_Shortage(IN p_ISBN char(13), IN p_Quantity int)
BEGIN
    IF EXISTS (SELECT 1 FROM T_SHORTAGE WHERE ISBN = p_ISBN AND Status = 'Unprocessed') THEN
        UPDATE T_SHORTAGE
        SET
            Source = CASE
                         WHEN Source = 'Auto' THEN 'Auto/User'
                         ELSE Source
                END,
            -- 取当前值与用户输入事实值中的较大者
            -- 确保库存回补充足
            Quantity = GREATEST(Quantity, p_Quantity),
            Shortage_Date = NOW()
        WHERE ISBN = p_ISBN AND Status = 'Unprocessed';
    ELSE
        -- 若无记录，直接按用户反馈的事实数量新建
        INSERT INTO T_SHORTAGE (ISBN, Shortage_Date, Quantity, Source, Status)
        VALUES (p_ISBN, NOW(), p_Quantity, 'User', 'Unprocessed');
    END IF;
END;

