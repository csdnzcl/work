create definer = root@localhost view v_sales_report as
select `b`.`ISBN`                                            AS `ISBN`,
       `b`.`Title`                                           AS `Title`,
       count(distinct `o`.`OrderID`)                         AS `Total_Orders`,
       sum(`od`.`Quantity`)                                  AS `Total_Sold_Copies`,
       sum((`od`.`Quantity` * ifnull(`od`.`Deal_Price`, 0))) AS `Total_Revenue`
from ((`onlinebookstore`.`t_books` `b` join `onlinebookstore`.`t_order_details` `od`
       on ((`b`.`ISBN` = `od`.`ISBN`))) join `onlinebookstore`.`t_orders` `o` on ((`od`.`OrderID` = `o`.`OrderID`)))
where (`o`.`Status` in ('Paid', 'Shipped'))
group by `b`.`ISBN`, `b`.`Title`
order by `Total_Revenue` desc;

