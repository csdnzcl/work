create definer = root@localhost trigger TR_Limit_Keywords
    before insert
    on t_book_keywords
    for each row
BEGIN
    DECLARE v_Count INT;
    SELECT COUNT(*) INTO v_Count FROM T_BOOK_KEYWORDS WHERE ISBN = NEW.ISBN;
    IF v_Count >= 10 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '错误：每本书最多只能添加10个关键字';
    END IF;
END;

