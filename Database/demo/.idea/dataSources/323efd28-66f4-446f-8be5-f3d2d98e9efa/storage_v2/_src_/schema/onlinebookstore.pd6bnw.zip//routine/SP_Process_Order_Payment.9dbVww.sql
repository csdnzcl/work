create
    definer = root@localhost procedure SP_Process_Order_Payment(IN p_OrderID int, OUT p_Result varchar(50))
BEGIN
    -- 定义变量
    DECLARE v_CustomerID INT;
    DECLARE v_TotalAmount DECIMAL(10,2);
    DECLARE v_Discount DECIMAL(3,2);
    DECLARE v_OverdraftLimit DECIMAL(10,2); -- 透支变量
    DECLARE v_Balance DECIMAL(10,2);
    DECLARE v_FinalPrice DECIMAL(10,2);
    DECLARE v_TotalSpent_Before DECIMAL(10,2);
    DECLARE v_CurrentLevel INT; -- 用于只升不降逻辑

    -- 异常处理
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET p_Result = 'Error: Transaction Rolled Back due to SQL Exception';
        END;

    START TRANSACTION;

    -- 1. 锁定订单与客户记录
    SELECT CustomerID, Total_Amount INTO v_CustomerID, v_TotalAmount
    FROM T_ORDERS WHERE OrderID = p_OrderID FOR UPDATE;

    SELECT Balance, Total_Spent, Credit_Level INTO v_Balance, v_TotalSpent_Before, v_CurrentLevel
    FROM T_CUSTOMERS WHERE CustomerID = v_CustomerID FOR UPDATE;

    -- 2. 获取当前折扣率及透支额度
    SELECT r.Discount, r.Overdraft_Limit INTO v_Discount, v_OverdraftLimit
    FROM T_CREDIT_RULES r
    WHERE r.Level = v_CurrentLevel;

    SET v_FinalPrice = v_TotalAmount * v_Discount;

    -- 3. 余额校验 (包含透支逻辑)
    IF v_Balance + v_OverdraftLimit < v_FinalPrice THEN
        UPDATE T_ORDERS SET Status = 'Payment Failed' WHERE OrderID = p_OrderID;
        COMMIT;
        SET p_Result = 'Fail: Insufficient funds (exceeds overdraft)';
    ELSE
        -- 4. 执行扣款与更新
        UPDATE T_ORDER_DETAILS SET Deal_Price = Unit_Price * v_Discount WHERE OrderID = p_OrderID;

        UPDATE T_CUSTOMERS
        SET Balance = Balance - v_FinalPrice,
            Total_Spent = Total_Spent + v_FinalPrice
        WHERE CustomerID = v_CustomerID;

        -- 5. 扣减库存 (依赖 T_BOOKS 的 CHECK 约束拦截超卖)
        UPDATE T_BOOKS b
            JOIN T_ORDER_DETAILS od ON b.ISBN = od.ISBN
        SET b.Stock_Qty = b.Stock_Qty - od.Quantity
        WHERE od.OrderID = p_OrderID;

        -- 6. 更新订单状态
        UPDATE T_ORDERS SET Status = 'Paid', Paid_Amount = v_FinalPrice WHERE OrderID = p_OrderID;

        -- 7. 自动升级信用等级 (只升不降逻辑)
        UPDATE T_CUSTOMERS
        SET Credit_Level = (
            SELECT GREATEST(v_CurrentLevel, MAX(Level))
            FROM T_CREDIT_RULES
            WHERE Min_Spend_Requirement <= (v_TotalSpent_Before + v_FinalPrice)
        )
        WHERE CustomerID = v_CustomerID;

        COMMIT;
        SET p_Result = 'Success: Payment processed';
    END IF;
END;

