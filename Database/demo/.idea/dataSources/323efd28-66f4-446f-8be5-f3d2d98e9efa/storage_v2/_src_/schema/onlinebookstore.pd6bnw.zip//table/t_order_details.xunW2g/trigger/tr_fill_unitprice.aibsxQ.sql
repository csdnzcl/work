create definer = root@localhost trigger TR_Fill_UnitPrice
    before insert
    on t_order_details
    for each row
BEGIN
    -- 如果插入时未指定单价，则自动从 T_BOOKS 获取当前定价
    IF NEW.Unit_Price IS NULL THEN
        SET NEW.Unit_Price = (SELECT Price FROM T_BOOKS WHERE ISBN = NEW.ISBN);
    END IF;
END;

