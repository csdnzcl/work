create definer = root@localhost trigger TR_Auto_Shortage_Reg_Insert
    after insert
    on t_books
    for each row
BEGIN
    -- 如果新录入的书库存就已经低于警戒线
    IF NEW.Stock_Qty < NEW.Min_Stock THEN
        INSERT INTO T_SHORTAGE (ISBN, Shortage_Date, Quantity, Source, Status)
        VALUES (NEW.ISBN, NOW(), (NEW.Min_Stock - NEW.Stock_Qty) + 10, 'Auto', 'Unprocessed');
    END IF;
END;

