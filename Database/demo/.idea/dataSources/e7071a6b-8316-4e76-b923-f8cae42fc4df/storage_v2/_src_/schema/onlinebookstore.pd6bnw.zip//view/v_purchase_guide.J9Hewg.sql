create definer = root@localhost view v_purchase_guide as
select `s`.`RecordID`                                                                    AS `RecordID`,
       `s`.`ISBN`                                                                        AS `ISBN`,
       `b`.`Title`                                                                       AS `Title`,
       `s`.`Quantity`                                                                    AS `Need_Qty`,
       `s`.`Shortage_Date`                                                               AS `Shortage_Date`,
       group_concat(concat(`sup`.`Name`, '(', `sup`.`Contact_Info`, ')') separator ', ') AS `Supplier_Info`
from (((`onlinebookstore`.`t_shortage` `s` join `onlinebookstore`.`t_books` `b`
        on ((`s`.`ISBN` = `b`.`ISBN`))) join `onlinebookstore`.`t_book_suppliers` `bs`
       on ((`b`.`ISBN` = `bs`.`ISBN`))) join `onlinebookstore`.`t_suppliers` `sup`
      on ((`bs`.`SupplierID` = `sup`.`SupplierID`)))
where (`s`.`Status` = 'Unprocessed')
group by `s`.`RecordID`, `s`.`ISBN`, `b`.`Title`, `s`.`Quantity`, `s`.`Shortage_Date`;

