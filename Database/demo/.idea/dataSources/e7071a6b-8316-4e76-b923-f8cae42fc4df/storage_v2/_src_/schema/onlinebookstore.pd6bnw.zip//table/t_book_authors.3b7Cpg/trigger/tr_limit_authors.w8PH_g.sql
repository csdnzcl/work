create definer = root@localhost trigger TR_Limit_Authors
    before insert
    on t_book_authors
    for each row
BEGIN
    DECLARE v_Count INT;
    SELECT COUNT(*) INTO v_Count FROM T_BOOK_AUTHORS WHERE ISBN = NEW.ISBN;
    IF v_Count >= 4 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '错误：每本书最多只能关联4位作者';
    END IF;
END;

