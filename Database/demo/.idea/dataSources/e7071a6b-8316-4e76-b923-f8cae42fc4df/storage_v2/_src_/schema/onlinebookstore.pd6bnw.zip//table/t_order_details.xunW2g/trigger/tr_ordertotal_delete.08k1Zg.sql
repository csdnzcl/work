create definer = root@localhost trigger TR_OrderTotal_Delete
    after delete
    on t_order_details
    for each row
BEGIN
    UPDATE T_ORDERS SET Total_Amount = Total_Amount - (OLD.Quantity * OLD.Unit_Price)
    WHERE OrderID = OLD.OrderID;
END;

