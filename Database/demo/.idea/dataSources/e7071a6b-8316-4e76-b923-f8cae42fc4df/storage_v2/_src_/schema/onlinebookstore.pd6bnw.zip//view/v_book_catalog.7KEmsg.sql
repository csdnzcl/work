create definer = root@localhost view v_book_catalog as
select `b`.`ISBN`                                                                       AS `ISBN`,
       `b`.`Title`                                                                      AS `Title`,
       `b`.`Publisher`                                                                  AS `Publisher`,
       `b`.`Price`                                                                      AS `Price`,
       `b`.`Stock_Qty`                                                                  AS `Stock_Qty`,
       `b`.`Min_Stock`                                                                  AS `Min_Stock`,
       group_concat(distinct `a`.`Name` order by `ba`.`Author_Rank` ASC separator ', ') AS `Authors`,
       `b`.`Series_Name`                                                                AS `Series_Name`
from ((`onlinebookstore`.`t_books` `b` left join `onlinebookstore`.`t_book_authors` `ba`
       on ((`b`.`ISBN` = `ba`.`ISBN`))) left join `onlinebookstore`.`t_authors` `a`
      on ((`ba`.`AuthorID` = `a`.`AuthorID`)))
group by `b`.`ISBN`, `b`.`Title`, `b`.`Publisher`, `b`.`Price`, `b`.`Stock_Qty`, `b`.`Min_Stock`, `b`.`Series_Name`;

-- comment on column v_book_catalog.Min_Stock not supported: 最低库存警戒线

